let age = 22;
const religion = "Catholic";
const hobbies = ["Reading", "Coding", "Gaming"];

function updateAge() {
    // Increment the age by 1 each time the button is clicked
    age++;
    
    // Update the displayed age in the HTML
    document.getElementById("age").innerText = age;
    
    // Log the updated age to the console
    console.log("Updated Age:", age);
}

// Initial display of age
document.getElementById("age").innerText = age;

// Log initial information to the console
console.log("Initial Age:", age);
console.log("Religion:", religion);
console.log("Hobbies:", hobbies.join(", "));
