const questions = [
    {
      question: "Which keyword is used to declare a variable in JavaScript?",
      options: ["var", "let", "const", "all of the above"],
      correctAnswer: "all of the above"
    },

    {
      question: "Which keyword is used to declare a variable in JavaScript?",
      options: ["var", "let", "const", "all of the above"],
      correctAnswer: "all of the above"
    },

    {
      question: "Which keyword is used to declare a variable in JavaScript?",
      options: ["var", "let", "const", "all of the above"],
      correctAnswer: "all of the above"
    },  
    // Add more questions and options for each topic
  ];
  
  const quizContainer = document.getElementById("question-container");
  const resultContainer = document.getElementById("result-container");
  const submitButton = document.getElementById("submit-btn");
  const restartButton = document.getElementById("restart-btn");
  restartButton.addEventListener("click", restartQuiz);
  
  function buildQuiz() {
    questions.forEach((question, index) => {
      const questionDiv = document.createElement("div");
      questionDiv.innerHTML = `<p>${index + 1}. ${question.question}</p>`;
      
      question.options.forEach((option, optionIndex) => {
        const input = document.createElement("input");
        input.type = "radio";
        input.name = `question${index}`;
        input.value = option;
        input.id = `q${index}o${optionIndex}`;
        
        const label = document.createElement("label");
        label.textContent = option;
        label.htmlFor = `q${index}o${optionIndex}`;
        
        questionDiv.appendChild(input);
        questionDiv.appendChild(label);
      });
  
      quizContainer.appendChild(questionDiv);
    });
  }
  
  function calculateScore() {
    let score = 0;
    questions.forEach((question, index) => {
      const selectedOption = document.querySelector(`input[name="question${index}"]:checked`);
      if (selectedOption) {
        if (selectedOption.value === question.correctAnswer) {
          score++;
        }
      }
    });
    return score;
  }
  
  function showResult() {
    const score = calculateScore();
    resultContainer.textContent = `Your score: ${score} out of ${questions.length}`;
    resultContainer.style.display = 'block';
  }
  
  submitButton.addEventListener("click", showResult);

  function restartQuiz() {
    // Clear selected answers
    const selectedOptions = document.querySelectorAll('input[type="radio"]:checked');
    selectedOptions.forEach(option => {
      option.checked = false;
    });
  
    // Hide result container and restart button
    hideResult();
    hideRestartButton();
  
    // Show submit button
    showSubmitButton();
  }

  function hideResult() {
    resultContainer.style.display = 'none';
  }
  
  function hideRestartButton() {
    restartButton.style.display = 'none';
  }
  
  function showSubmitButton() {
    submitButton.style.display = 'inline-block';
  }

  restartButton.addEventListener("click", restartQuiz);

  // Build the quiz when the page loads
  document.addEventListener("DOMContentLoaded", () => {
    buildQuiz();
  });

  submitButton.addEventListener("click", () => {
    showResult();
    hideSubmitButton();
    showRestartButton();
  });
  
  function hideSubmitButton() {
    submitButton.style.display = 'none';
  }
  
  function showRestartButton() {
    restartButton.style.display = 'inline-block';
  }
  